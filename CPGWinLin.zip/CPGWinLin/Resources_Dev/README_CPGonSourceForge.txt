CPG 

Releases contain software downloads: working applications with Test Data and examples, ready to run on Mac, Windows or Linux, Solaris.

To read all about the Application, see README_CPG in Documentation and within the Coulson Plot Generator itself.
Documentation for programmers and Users is provided.

Source code from 9 March 2013 may be downloaded e.g. to a directory coulson, by issuing the following command: 
svn co https://coulson.svn.sourceforge.net/svnroot/coulson coulson
Support files are also included.

Now includes xalan source code in coulson/src/org - Feb 2013
The xalan licence is now part of CPG documentation.

The Documentation folder describes how to develop CPG in Eclipse, and generate Applications therefrom.

HIF.

Version 1.1 released October 29 2012
Version 1.5 released March 9 2013


